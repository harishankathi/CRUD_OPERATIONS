function deleteUser(i) {
  users.splice(i, 1);
  displayUsers(users);
  localStorage.setItem("users", JSON.stringify(users));
}
