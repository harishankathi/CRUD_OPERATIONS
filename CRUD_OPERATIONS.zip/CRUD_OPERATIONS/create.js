// var users = [];
var users = JSON.parse(localStorage.getItem("users"));
if (users) {
  displayUsers(users);
} else {
  users = [];
}
function getValues() {
  var person = {
    email: "",
    password: "",
  };
  // person.email = document.getElementById("email").value;
  // person.password = document.getElementById("password").value;
  for (a in person) {
    person[a] = document.getElementById(a).value;
  }
  users.push(person);
  localStorage.setItem("users", JSON.stringify(users));
  displayUsers(users);
}
function displayUsers(users) {
  document.getElementById("myTable").innerHTML = "";
  users.map(function (obj, i) {
    var myTr = document.createElement("tr");
    for (a in obj) {
      var myTd = document.createElement("td");
      myTd.innerHTML = obj[a];
      myTr.appendChild(myTd);
    }

    var editTd = document.createElement("td");
    var deleteTd = document.createElement("td");

    var editbtn = document.createElement("button");
    editbtn.innerHTML = "Edit";
    editbtn.setAttribute("class", "btn btn-primary");

    var deletebtn = document.createElement("button");
    deletebtn.innerHTML = "Delete";
    deletebtn.setAttribute("class", "btn btn-danger");
    deletebtn.setAttribute("onclick", "deleteUser(" + i + ")");

    editTd.appendChild(editbtn);
    deleteTd.appendChild(deletebtn);
    myTr.appendChild(editTd);
    myTr.appendChild(deleteTd);
    document.getElementById("myTable").appendChild(myTr);
  });
}
